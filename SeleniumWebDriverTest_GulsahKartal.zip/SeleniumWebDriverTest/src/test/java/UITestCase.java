
//import org.openqa.selenium.bidi.network.Cookie;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class UITestCase {

	public static void main(String[] args) throws InterruptedException {
		
		String baseURL = "https://www.amazon.com/";
		
		WebDriverManager.chromedriver().setup();
		 	     
	    ChromeOptions chromeOptions = new ChromeOptions();
	    chromeOptions.setExperimentalOption("excludeSwitches", Arrays.asList("enable-automation"));    
	    ChromeDriver driver = new ChromeDriver(chromeOptions);

	    //The website is opened.
	    driver.get(baseURL);
	    //Pass the CAPTCHA manually within 10 seconds.
	    Thread.sleep(10000);

		//The main page of the website is opened.
		//Enter the word "laptop" on the search bar and list the laptops on the website
	    WebElement element = driver.findElement(By.id("twotabsearchtextbox"));
	    element.sendKeys("laptop");
	    element.sendKeys(Keys.RETURN); 
		Thread.sleep(2000);
		
		//Add any of the items which are in-stock and non-discounted on the first page
		//Add to cart one by one (8 item in total)
		WebElement element1 = driver.findElement(By.id("a-autoid-3-announce"));
	    element1.sendKeys(Keys.RETURN); 
	    
	    WebElement element2 = driver.findElement(By.id("a-autoid-5-announce"));
	    element2.sendKeys(Keys.RETURN); 
	    
	    //Scroll down
	    JavascriptExecutor js = (JavascriptExecutor) driver;
	    js.executeScript("window.scrollBy(0,350)", "");
	    
	    Thread.sleep(2000);
	    
	    WebElement element3 = driver.findElement(By.id("a-autoid-6-announce"));
	    element3.sendKeys(Keys.RETURN); 
	    
	    WebElement element4 = driver.findElement(By.id("a-autoid-10-announce"));
	    element4.sendKeys(Keys.RETURN);
	    
	    //Scroll down
	    js.executeScript("window.scrollBy(0,350)", "");
	    
	    Thread.sleep(2000);
	    
	    WebElement element5 = driver.findElement(By.id("a-autoid-12-announce"));
	    element5.sendKeys(Keys.RETURN); 
	    
	    WebElement element6 = driver.findElement(By.id("a-autoid-13-announce"));
	    element6.sendKeys(Keys.RETURN);
	    
	    //Scroll down
	    js.executeScript("window.scrollBy(0,350)", "");
	    
	    Thread.sleep(2000);
	    
	    WebElement element7 = driver.findElement(By.id("a-autoid-16-announce"));
	    element7.sendKeys(Keys.RETURN);
//	    
	    WebElement element8 = driver.findElement(By.id("a-autoid-21-announce"));
	    element8.sendKeys(Keys.RETURN);
	    
	    Thread.sleep(2000);    
	    
	    //Scroll up to the view of cart
	    js.executeScript("window.scrollBy(0, -1000)", "");
	    Thread.sleep(2000);  
//	    js.executeScript("window.scrollBy(0, -1000)", "");
	    Thread.sleep(2000); 
	    
	    //Display the cart content
	    WebElement el = driver.findElement(By.id("nav-cart"));
	    el.sendKeys(Keys.RETURN);
	    

	}

}
