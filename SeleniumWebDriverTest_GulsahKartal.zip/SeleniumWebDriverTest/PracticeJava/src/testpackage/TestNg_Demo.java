package testpackage;

import org.testng.Assert;
import org.testng.annotations.Test;

import appcode.SomeClassToTest;

public class TestNg_Demo {

	@Test
	public void testSum()
	{
		SomeClassToTest obj = new SomeClassToTest();
		int result = obj.sumNumbers(2, 6);
		System.out.println("\nRunning Test -> testSum");
		Assert.assertEquals(result, 8);
	}
	@Test
	public void testStrings()
	{
		System.out.println("\nRunning Test -> testStrings");
		String expectedString = "Hello World";
		SomeClassToTest obj = new SomeClassToTest();
		String result = obj.addString("Hello", "World");
		Assert.assertEquals(result, expectedString);
	}
	@Test
	public void testArrays()
	{
		System.out.println("\nRunning Test -> testArrays");
		int[] expectedArray = {1, 2, 3};
		SomeClassToTest obj = new SomeClassToTest();
		int[] result = obj.getArray();
		Assert.assertEquals(result, expectedArray);
	}
}
