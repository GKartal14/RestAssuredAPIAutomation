package testpackage;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import appcode.SomeClassToTest;

public class TestNg_SoftAsserts {

	@Test
	public void testSum()
	{
		SoftAssert sa = new SoftAssert();
		System.out.println("\nRunning Test -> testSum");
		SomeClassToTest obj = new SomeClassToTest();
		int result = obj.sumNumbers(3, 8);
		sa.assertEquals(result, 11);
		System.out.println("\nLine after assert 1");
		int result2 = obj.sumNumbers(3,  -5);
		sa.assertEquals(result2, -2);
		System.out.println("\nLine after assert 2");
		sa.assertAll();
	}
}
