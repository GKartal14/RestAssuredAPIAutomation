package testpackage;

import org.testng.annotations.Test;

import base.BaseTestSuite;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class TestNg_Class1 extends BaseTestSuite{
 
  @BeforeClass
  public void setup()
  {
	  System.out.println("\nThis runs before class one.");
  }
  @AfterClass
  public void cleanup()
  {
	  System.out.println("\nThis runs after class one.");
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("\nThis runs before every method");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("\nThis runs after every method");
  }
  @Test
  public void testMethod1() {
	  System.out.println("\nTestNG - TestClass1: Running Test -> testMethod1");
  }
  @Test
  public void testMethod2() {
	  System.out.println("\nTestNG - TestClass1: Running Test -> testMethod2");
  }

}
