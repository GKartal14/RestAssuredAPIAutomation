package testpackage;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import appcode.SomeClassToTest;

public class TestNG_DependentTests {

  SomeClassToTest obj;
  @BeforeClass
  public void setUp()
  {
	  obj = new SomeClassToTest();
	  System.out.println("before test");
  }
  @AfterClass
  public void cleanUp()
  {
	  System.out.println("after test.");
  }
  @Test(dependsOnMethods={ "testMethod2" }, alwaysRun=true)
  public void testMethod1() {
	  System.out.println("Test method 1");
  }
  @Test
  public void testMethod2() {
	  System.out.println("Test method 2");
	  int result = obj.sumNumbers(1, 2);
	  Assert.assertEquals(result, 3);
  }
  @Test(dependsOnMethods={ "testMethod1" }, alwaysRun=true)
  public void testMethod3() {
	  System.out.println("Test method 3");
  }
  @Test(enabled=false)
  public void testMethod4() {
	  System.out.println("Test method 4");
  }
  @Test(timeOut=400)
  public void testMethod5() throws InterruptedException
  {
	  System.out.println("Test method 5");
	  Thread.sleep(300);
  }
}
