package testpackage;

import org.testng.annotations.Test;
import testpackage.SimpleTestFactory;

public class SimpleTest {

	private int param;
	public SimpleTest(int param)
	{
		this.param = param;
	}
    @Test
    public void testMethodOne() {
    	int opValue = param + 1;
    	System.out.println("Test method one output: " + opValue);
    }
    @Test
    public void testMethodTwo() {
    	int opValue = param + 2;
    	System.out.println("Test method two output: " + opValue);
    }
}
