package Various;

public class TurnTaker {
	
	private static int turn = 0;
	
	private int myTurn;
	private String name;
	
	public TurnTaker(String theName, int theTurn)
	{
		name = theName;
		if(theTurn >= 0)
		{
			myTurn = theTurn;
		}
		else
		{
			System.exit(0);
		}
	}
	public TurnTaker()
	{
		myTurn = 0;
		name = "No name yet.";
	}
	public String getName()
	{
		return name;
	}
	public static int getTurn()
	{
		turn++;
		return turn;
	}
	public boolean isMyTurn()
	{
		return (turn == myTurn);
	}
	public static void main(String[] args)
	{
		TurnTaker lover1 = new TurnTaker("Romeo", 1);
		TurnTaker lover2 = new TurnTaker("Juliet", 3);
		
		for(int i = 1; i < 5; i++)
		{
			System.out.println("Turn = " + TurnTaker.getTurn());
			if(lover1.isMyTurn())
			{
				System.out.println("Love from " + lover1.getName());
			}
			else
			{
				System.out.println("Love from " + lover2.getName());
			}
		}
	}

}
