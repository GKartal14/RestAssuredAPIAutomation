package Various;

public class PartiallyFilledArray {
 
	private int maxNumberElements; //same as a.length
	private double[] a;
	private int numberUsed; //number of indices currently in use
}
