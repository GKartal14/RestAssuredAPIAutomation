package GulsahKartalJavaTask;

public class GulsahKartalJavaTask {

}
