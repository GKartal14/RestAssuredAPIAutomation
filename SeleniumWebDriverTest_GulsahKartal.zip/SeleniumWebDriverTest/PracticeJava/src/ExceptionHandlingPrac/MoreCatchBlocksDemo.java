package ExceptionHandlingPrac;

import java.util.Scanner;
import java.lang.Throwable;


public class MoreCatchBlocksDemo{

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		try
		{
			System.out.println("How many pencils do you have?");
			int pencils = keyboard.nextInt();
			
			if(pencils < 0)
			{
				throw new Exception("pencils");
				System.out.println("Negative number exception");
			}
			System.out.println("How many erasers do you have?");
			int erasers = keyboard.nextInt();
			double pencilsPerEraser;
			
			if(erasers < 0)
			{
				throw new Exception("erasers");
				System.out.println("Negative number exception 2");
			}
			else if(erasers != 0)
			{
				pencilsPerEraser = pencils / (double)erasers;
			}
			else
			{
				throw new Exception();
				System.out.println("Division by zero exception");
			}
			System.out.println("Each eraser must last through " + pencilsPerEraser + " pencils.");
			
		}
		catch(Exception e)
		{
			System.out.println("Cannot have a negative number of " + e.getMessage());
		}
		/*catch(Exception e2)
		{
			System.out.println("Do not make any mistakes."); 
		}*/

	}

}
