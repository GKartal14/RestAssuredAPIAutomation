package ExceptionHandlingPrac;

import java.util.Scanner;

public class DanceLesson {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter number of male dancers: ");
		int men = keyboard.nextInt();
		
		System.out.println("Enter number of female dancers: ");
		int women = keyboard.nextInt();
		
		try
		{
			if(men == 0 && women == 0)
			{
				throw new Exception("The lesson is cancelled. No students");
			}
			else if(men == 0)
			{
				throw new Exception("The lesson is cancelled. No men.");
			}
			else if(women == 0)
			{
				throw new Exception("The lesson is cancelled. No women.");
			}
			if(women >= men)
			{
				System.out.println("Each man must dance with " + women / (double)men);
			}
			else
			{
				System.out.println("Each woman must dance with " + men / (double) women);
			}
		}
		catch(Exception e)
		{
			String message = e.getMessage();
			System.out.println(message);
			System.exit(0);
		}
		System.out.println("Begin the lesson.");
	}

}
