package ExceptionHandlingPrac;

import java.util.Scanner;
import java.util.
import java.lang.Throwable;

public class DivisionDemoSecondVersion {

	public static double safeDivide(int top, int bottom) throws DivisionByZeroException
	{
		if(bottom == 0)
			throw new DivisionByZeroException();
		return top / (double) bottom;
	}
	public static void secondChance()
	{
		Scanner keyboard = new Scanner(System.in);
		try
		{
			System.out.println("Enter the numerator: ");
			int numerator = keyboard.nextInt();
			System.out.println("Enter the denominator: ");
			int denominator = keyboard.nextInt();
			
			double quotient = numerator / (double) denominator;
			
			System.out.println(numerator + " / " + denominator + " = " + quotient);
		}
		catch(DivisionByZeroException e)
		{
			System.out.println("cannot divide bu zero. abort the program.");
			System.exit(0);
		}
	}
}
