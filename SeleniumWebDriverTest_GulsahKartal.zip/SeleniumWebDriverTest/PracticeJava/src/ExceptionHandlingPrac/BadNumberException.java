package ExceptionHandlingPrac;

import java.util.Scanner;

public class BadNumberException extends Exception{

	private int badNumber;
	
	public BadNumberException()
	{
		super("BadNumberException");
		badNumber = 0;
	}
	public BadNumberException(int number)
	{
		super("BadNumberException");
		badNumber = number;
	}
	public BadNumberException(String message)
	{
		super(message);
	}
	public int getBadNumber()
	{
		return badNumber;
	}
	public static void main(String[] args)
	{
		try
		{
			Scanner keyboard = new Scanner(System.in);
			System.out.println("Enter one of the numbers 42 and 24: ");
			int inputNumber = keyboard.nextInt();
			
			if((inputNumber != 24)&&(inputNumber != 42))
			{
				throw new BadNumberException(inputNumber);
			}
			
			System.out.println("Thank you for entering " + inputNumber);
			
		}
		catch(BadNumberException e)
		{
			System.out.println(e.getBadNumber() + " is not what I asked for");
		}
		System.out.println("End of the program.");
	}
}
