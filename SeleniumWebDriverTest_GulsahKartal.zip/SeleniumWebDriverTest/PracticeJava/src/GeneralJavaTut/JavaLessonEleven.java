
package GeneralJavaTut;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Arrays;

public class JavaLessonEleven {

	public static void main(String[] args) {
		
		ArrayList arrayListOne;
		
		arrayListOne = new ArrayList();
		
		ArrayList arrayListTwo = new ArrayList(); 
		
		ArrayList<String> names = new ArrayList<String>();
		
		names.add("Naruto Uzumaki");
		names.add("Sasuke Uchiha");
		names.add("Shikamaru Nara");
		
		names.add(2, "Sakura Haruno");
		
		for(int i = 0; i < names.size(); i++)
		{
			System.out.println(names.get(i));
		}
		System.out.println(names);
		
		for(String i : names)
		{
			System.out.println(i);
		}
		
		Iterator indivItems = names.iterator();
		
		while(indivItems.hasNext())
		{
			System.out.println(indivItems.next());
		}
		
		ArrayList nameCopy = new ArrayList();
		nameCopy.addAll(names);
		
		ArrayList nameBackup = new ArrayList();
		
		String hatakekakashi = "Hatake Kakashi";
		names.add(hatakekakashi);
		
		if(names.contains(hatakekakashi))
		{
			System.out.println("Kakashi Sensei is here.");
		}
		if(names.containsAll(names))
		{
			System.out.println("Everything in nameCopy is in names.");
		}
		
		names.clear();
		
		if(names.isEmpty())
		{
			System.out.println("ArrayList is empty");
		}
		
		Object[] morenames = new Object[4];// from ArrayList to Array
		morenames = nameCopy.toArray();// from ArrayList to Array
		
		System.out.println(Arrays.toString(morenames));

	}

}
