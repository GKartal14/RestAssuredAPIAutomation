package GeneralJavaTut;

public class Vehicle extends Crashable implements Drivable, Cloneable{//any method in the interface has to be implemented, Crashable is abstract class

	int numOfWheels = 2;
	double theSpeed = 0;
	int carStrength = 0;
	
	
	public int getWheel()
	{
		return this.numOfWheels;
	}
	
	public void setWheels(int numWheels)
	{
		this.numOfWheels = numWheels;
	}
	
	public double getSpeed()
	{
		return this.theSpeed;
	}
	
	public void setSpeed(double speed)
	{
		this.theSpeed = speed;
	}
	public Vehicle(int wheels, double speed)
	{
		this.numOfWheels = wheels;
		this.theSpeed = speed;
		
	}
	public Vehicle()
	{
		
	}
	public int getCarStrength()
	{
		return this.carStrength;
	}
	
	public void setCarStrength(int carStrength)
	{
		this.carStrength = carStrength;
	}
	public String toString()
	{
		return "Num of wheels: " + this.numOfWheels;
	}
	public Object clone()
	{
		Vehicle car;
		
		try
		{
			car = (Vehicle) super.clone(); //parent clone metodu �a�r�ld� ve Vehicle'a cast edildi. car klonland�.
		}
		catch(CloneNotSupportedException e)
		{
			return null; 
		}
		return car;
	}
}
