package GeneralJavaTut;

public class LessonSeventeen {

	public static void main(String[] args) {
		
		Thread getTime = new GetTime20();
		
		getTime.start();

	}

}
