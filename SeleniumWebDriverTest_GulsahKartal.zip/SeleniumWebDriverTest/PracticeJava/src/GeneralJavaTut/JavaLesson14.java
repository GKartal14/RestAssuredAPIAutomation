package GeneralJavaTut;

public class JavaLesson14 {

	public static void main(String[] args) {
		
		Animals genericAnimal = new Animals();
		
		System.out.println(genericAnimal.getName());//name private
		System.out.println(genericAnimal.favFood); //favFood public
		
		Cats morris = new Cats("Morris", "Tuna fish", "Rubber mouse");
		
		System.out.println();
		
		System.out.println(morris.getName());//private
		System.out.println(morris.favFood);//public
		System.out.println(morris.favToy);//public
		
		Animals tabby = new Cats("Tabby", "Whiskas", "Plastic Ball");//upcasting
		
		acceptAnimal(tabby);
		
		

	}
	public static void acceptAnimal(Animals randomAnimal)
	{
		System.out.println();
		System.out.println(randomAnimal.getName());
		System.out.println(randomAnimal.favFood);
		System.out.println();
		
		randomAnimal.walkAround();//overridden version in the child class
		
		Cats tempCat = (Cats) randomAnimal;//downcasting
		
		System.out.println(tempCat.favToy);
		
		if(randomAnimal instanceof Cats)
		{
			System.out.println(randomAnimal.getName() + " is a cat.");
		}
	}

}
