package GeneralJavaTut;

import java.util.Arrays;
import java.util.LinkedList;

public class JavaLessonTwelve
{
	public static void main(String[] args)
	{
		LinkedList linkedListOne = new LinkedList();
		
		LinkedList<String> names = new LinkedList<String>();
		
		names.add("Ichigo Kurosaki");
		names.add("Kisuke Urahara");
		
		names.addLast("Rukia Kuchiki");
		
		names.addFirst("Sousuke Aizen");
		
		names.add(0, "Retsu Unohana");
		
		names.set(2, "Yoruichi Shioin");//rukia ve kisuke bir sonraki index'e kayd�
		
		
		for(String name : names)
		{
			System.out.println(name);
		}
		System.out.println("\nFirst Index: " + names.get(0));
		
		System.out.println("\nLast Index: " + names.getLast());
		
		LinkedList<String> nameCopy = new LinkedList<String>(names);
		
		System.out.println("\nnameCopy: " + nameCopy);
		
		if(names.contains("Sousuke Aizen"))
		{
			System.out.println("\nAizen-sama is here.");
		}
		if(names.containsAll(nameCopy))
		{
			System.out.println("\nCollections the same");
		}
		System.out.println("\nSecond Index: " + names.get(1));
		
		System.out.println("\nRukia is index at: " + names.indexOf("Rukia Kuchiki"));
		
		System.out.println("\nList Empty: " + names.isEmpty());
		
		System.out.println("How many names: " + names.size());
		
		System.out.println("\nremove first element: " + nameCopy.poll());//poll() list'teki ilk elementi remove eder
		System.out.println("\nremove last element: " + nameCopy.pollLast());//pollLast() list'teki son elementi remove eder
		System.out.println("\nLook without error: " + nameCopy.peek()); //List'teki ilk elementi basar. s�f�r�nc� index.
		
		nameCopy.push("Ulquiorra Schiffer");//push() s�f�r�nc� index'e element yerle�tirir (stack)
		//nameCopy.pop(); s�f�r�nc� indexteki elementi listeden atar (stack)
		
		for(String name : nameCopy)
		{
			System.out.println(name);
		}
		Object[] nameArray = new Object[4];
		
		nameArray = names.toArray();
		
		System.out.println(Arrays.toString(nameArray));//linked listten array e cevirir
	}
}