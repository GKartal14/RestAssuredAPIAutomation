package GeneralJavaTut;

public class LessonFifteen {

	public static void main(String[] args)
	{
		Vehicle car = new Vehicle(4, 100.00);
		
		System.out.println("Cars max speed " + car.getSpeed());
		System.out.println("Num of wheels " + car.getWheel());
		
		car.setCarStrength(200);; //burada set edildi
		System.out.println("Strength: " + car.getCarStrength());//burada bas�ld�
		
		Object superCar = new Vehicle();
		
		System.out.println(((Vehicle)superCar).getSpeed());
		
		Vehicle superTruck = new Vehicle();
		
		System.out.println(superCar.equals(superTruck));
		
		System.out.println(superCar.hashCode());
		
		System.out.println(superCar.getClass());
		
		System.out.println(superCar.getClass().getSuperclass());
		
		if(superCar.getClass() == superTruck.getClass())
		{
			System.out.println("The same");
		}
		System.out.println(superCar.toString());
		
		//wrapper class primitive object type a donusur: int, double
		
		int randNum = 100;
		System.out.println(Integer.toString(randNum));
		
		float randNum2 = 134.245F;
		System.out.println(Float.toString(randNum2));
		
		superTruck.setWheels(8);
		
		Vehicle superTruck2 = (Vehicle)superTruck.clone();
		
		System.out.println(superTruck.getWheel());//cloned
		System.out.println(superTruck2.getWheel()); //same as the cloned
		
		System.out.println(superTruck.hashCode());
		System.out.println(superTruck2.hashCode());
		
		
	}
}
