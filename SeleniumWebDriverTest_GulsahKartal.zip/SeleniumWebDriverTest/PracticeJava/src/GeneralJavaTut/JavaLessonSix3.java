import java.io.*;
package GeneralJavaTut;

public class JavaLessonSix3 {

	public static void main(String[] args) {
		getAFile("./somestuff.txt");

	}
	/*public static void getAFile(String fileName)
	{
		try
		{
			FileInputStream file = new FileInputStream(fileName);
		}
		catch(FileNotFoundException e)
		{
			System.out.println("Sorry can't find that file.");
		}
		catch(ClassNotFoundException | IOException e)
		{
			System.out.println("Unknown class or IO error.");
		}
		catch(Exception e)
		{
			System.out.println("Some error occured.");
		}
		finally
		{
			System.out.println("the end");
		}
	}*/
	public static void getAFile(String FileName) throws IOException, FileNotFoundException
	{
		FileInputStream file = new FileInputStream(fileName);
	}
}
