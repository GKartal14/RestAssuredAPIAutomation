package GeneralJavaTut;

import java.util.Arrays;

public class JavaLesson13 {

	public static void main(String[] args) {
		String randomString = "I'm just a random string";
		
		String gotToQuote = "He said \"I'm here\" ";
		
		int numTwo = 2;
		
		System.out.println(randomString + " " + numTwo);
		
		String uppercaseStr = "BIG";
		String lowercaseStr = "big";
		
		if(uppercaseStr.equalsIgnoreCase(lowercaseStr))
		{
			System.out.println("They are equal");
		}
		String letters = "abcde";
		
		String moreletters = "fghijk";
		
		System.out.println("2nd char: " + letters.charAt(1));
		
		System.out.println(letters.compareTo(moreletters));
		
		System.out.println(letters.contains("abc"));
		
		System.out.println(letters.endsWith("de"));
		
		System.out.println(letters.indexOf("cd"));
		
		System.out.println(letters.replace("abc", "xy"));
		
		char[] charArray = letters.toCharArray();
		
		System.out.println(Arrays.toString(charArray));
		
		System.out.println(letters.substring(1,3));
		
		System.out.println(letters.toUpperCase());
		
		String randString = "	hdfgdfg		";
		
		System.out.println(randString.trim());
		
		StringBuilder randSB = new StringBuilder("A random value");
		
		System.out.println(randSB.append(" once again"));
		
		System.out.println(randSB.delete(15, 21));
		
		randSB.ensureCapacity(60);

		System.out.println(randSB.capacity());//how much total space you have in memory
		
		randSB.trimToSize(); //ensure your capacity consists of the number of characters in the string
		
		System.out.println(randSB.capacity());
		
		System.out.println(randSB.insert(1, "nother"));
		
		String oldSB = randSB.toString(); //convert stringbuilder to string
		

	}

}
