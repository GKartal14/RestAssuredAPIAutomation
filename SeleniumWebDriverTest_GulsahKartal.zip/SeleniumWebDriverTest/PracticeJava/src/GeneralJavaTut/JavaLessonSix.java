package GeneralJavaTut;

public class JavaLessonSix {

	public static void main(String[] args) {
		divideByZero(2);

	}
	public static void divideByZero(int number)
	{
		try{
			System.out.println(number/0);
		}
		catch(ArithmeticException e)
		{
			System.out.println("you can't do that.");
			
			System.out.println(e.getMessage());
			
			e.printStackTrace();
		}
	}

}
