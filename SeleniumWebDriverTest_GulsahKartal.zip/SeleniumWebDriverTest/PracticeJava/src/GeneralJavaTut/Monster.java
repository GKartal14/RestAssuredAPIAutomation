package GeneralJavaTut;

public class Monster {
	
	public final String TOMBSTONE = "Here lies a dead monster";
	
	private int health = 500;
	private int attack  = 20;
	private int movement = 2;
	private int xPosition = 0;
	private int yPosition = 0;
	private boolean alive = true;
	
	public String name  = "Big monster";
	
	public int getAttack()
	{
		return attack;
	}
	public int getHealth()
	{
		return health;
	}
	public int getMovement()
	{
		return movement;
	}
	public void setHealth(int decreaseHealth)
	{
		health = health - decreaseHealth;
		if(health < 0)
		{
			alive = false;
		}
	}
	public void setHealth(double decrease)
	{
		int intDecreaseHealth = (int) decrease;
		health = health - intDecreaseHealth;
		if(health < 0)
		{
			alive = false;
		}
	}
	public Monster(int health, int attack, int movement)
	{
		this.health = health;
		this.attack = attack;
		this.movement = movement;
	}
	
	//default constructor
	public Monster()
	{
		
	}
	public Monster(int newHealth)
	{
		health = newHealth;
	}
	public Monster(int newHealth, int newAttack)
	{
		this(newHealth);
		attack = newAttack;
	}

	public static void main(String[] args) {
		
		Monster Frank = new Monster();
		System.out.println(Frank.attack); //frank.attack (private attr because we are still inside of the class)
		//if we are outside of the class, the main class is outside of the class, write -> Frank.getAttack()
		System.out.println(Frank.health);//Frank.getHealth()
		System.out.println(Frank.movement);//Frank.getMovement()

	}

}
