package GeneralJavaTut;

public abstract class Crashable {
	
	boolean carDrivable = true;
	
	public abstract int getCarStrength();
	
	public abstract void setCarStrength(int carStrength);
}
