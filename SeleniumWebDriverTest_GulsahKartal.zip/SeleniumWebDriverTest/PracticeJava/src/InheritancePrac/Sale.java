package InheritancePrac;

public class Sale {
	private String name; //nonempty
	private double price; //nonnegative
	
	public Sale()
	{
		name = null;
		price = 0;
	}
	public Sale(String theName, double thePrice)
	{
		if(theName == null || thePrice == 0)
		{
			System.exit(0);
		}
		else
		{
			name = theName;
			price = thePrice;
		}
	}
	public Sale(Sale originalObject)
	{
		if(originalObject == null)
		{
			System.exit(0);
		}
		else
		{
			name = originalObject.name;
			price = originalObject.price;
		}
	}
	public static void announcement()
	{
		System.out.println("This is the Sale class");
	}
	public double getPrice()
	{
		return price;
	}
	public String getName()
	{
		return name;
	}
	public void setPrice(double newPrice)
	{
		if(newPrice <= 0)
		{
			System.exit(0);
		}
		else
		{
			price = newPrice;
		}
	}
	public void setName(String newName)
	{
		if(newName == null && newName == "")
		{
			System.exit(0);
		}
		else
		{
			name = newName;
		}
	}
	public String toString()
	{
		return(name + " Price and total cost = $" + price);
	}
	public double bill()
	{
		return price;
	}
	public boolean equalDeals(Sale otherSale)
	{
		if(otherSale == null)
		{
			return false;
		}
		else
			return(name.equals(otherSale.name) && bill() == otherSale.bill());
	}
	public boolean lessThan(Sale otherSale)
	{
		if(otherSale == null)
		{
			return false;
		}
		else
			return (bill() < otherSale.bill());
	}
	public boolean equals(Object otherObject)
	{
		if(otherObject == null)
		{
			return false;
		}
		else if(getClass() != otherObject.getClass())
		{
			return false;
		}
		else
		{
			Sale otherSale = (Sale) otherObject;
			return (name.equals(otherSale.name) && price == otherSale.price);
		}
	}
}
