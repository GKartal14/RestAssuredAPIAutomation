package InheritancePrac;
import InheritancePrac.*;

public class InteritanceDemo {

	public static void main(String[] args)
	{
		HourlyEmployee joe = new HourlyEmployee("Joe Smith", new Date("March", 8, 2011), 20.23, 140);
		
		System.out.println("John's longer name is " + joe.getName());
		
		System.out.println("Change joe's name to josephine");
		
		joe.setName("josephine");
		
		System.out.println("joe's record is as follows");
		
		System.out.println(joe);
	}
}
