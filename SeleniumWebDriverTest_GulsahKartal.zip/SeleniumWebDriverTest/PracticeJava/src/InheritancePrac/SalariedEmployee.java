package InheritancePrac;

public class SalariedEmployee extends Employee{
	
	private double salary;
	
	public SalariedEmployee()
	{
		super();
		salary = 0;
	}
	public SalariedEmployee(double theSalary, String theName, Date theDate)
	{
		super(theName, theDate);
		if(salary >= 0)
		{
			salary = theSalary;
		}
		else
		{
			System.exit(0);
		}
	}
	public SalariedEmployee(SalariedEmployee originalObject)
	{
		super(originalObject);
		salary = originalObject.salary;
	}
	public double getSalary()
	{
		return salary;
	}
	public void setSalary(double newSalary)
	{
		if(newSalary >= 0)
		{
			salary = newSalary;
		}
		else
		{
			System.exit(0);
		}
	}
	public double getPay()
	{
		return salary/12;
	}
	public String toString()
	{
		return (getName() + " " + getHireDate().toString() + "\n$" + salary + " per year");
	}
	public boolean equals(SalariedEmployee other)
	{
		return(getName().equals(other.getName()) && getHireDate().equals(other.getHireDate()) && salary == other.salary);
	}
}
