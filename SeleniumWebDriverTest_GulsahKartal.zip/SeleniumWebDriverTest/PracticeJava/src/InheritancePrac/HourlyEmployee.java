package InheritancePrac;
import InheritancePrac.*;
 
public class HourlyEmployee extends Employee{
	private double wageRate;
	private double hours; //for the month
	
	public hourlyEmployee()
	{
		super();//inherited the related constructor
		wageRate = 0;
		hours = 0;
	}
	
	
	//precond: theName and theDate are not null
	
	public HourlyEmployee(String theName, Date theDate, double theWageRate, double theHours)
	{
		super(theName, theDate);//inherited the related parent constructor
		if(theWageRate >= 00 && theHours >= 0)
		{
			wageRate = theWageRate;
			hours = theHours;
		}
		else
		{
			System.exit(0);
		}
	}
	public HourlyEmployee(HourlyEmployee originalObject)
	{
		super(originalObject);
		wageRate = originalObject.wageRate;
		hours = originalObject.hours;
	}
	public double getWageRate()
	{
		return wageRate;
	}
	public double getHours()
	{
		return hours;
	}
	public double getPay()
	{
		return (wageRate * hours);
	}
	public void setHours(double hoursWorked)
	{
		if(hoursWorked >= 0)
		{
			hours = hoursWorked;
		}
		else
		{
			System.exit(0);
		}
	}
	//precond: newWageRate is nonnegative
	public void setRate(double newWageRate)
	{
		if(newWageRate >= 0)
		{
			wageRate = newWageRate;
		}
		else
		{
			System.exit(0);
		}
	}
	public String toString()
	{
		return(getName() + " " + getHireDate().toString() + "\n$" + wageRate + " per hour for " + hours + " hours");
	}
	public boolean equals(HourlyEmployee other)
	{
		return(getName().equals(other.getName()) && getHireDate().equals(other.getHireDate()) && wageRate == other.wageRate && hours == other.hours);
	}
	
}
