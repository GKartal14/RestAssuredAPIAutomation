package InheritancePrac;
import InheritancePrac.*;

public abstract class Employee {

	private String name;
	private Date hireDate;
	
	public abstract double getPay();
	
	public Employee()
	{
		name = "No name";
		hireDate = new Date("January", 1, 1000); //just a placeholder
	}
	//precond: theName, theDate are not null
	
	public Employee(String theName, Date theDate)
	{
		if(theName == null || theDate == null)
		{
			System.out.println("fatal error");
			System.exit(0);
		}
		name = theName;
		hireDate = new Date(theDate);
	}
	public Employee(Employee originalObject)
	{
		name = originalObject.name;
		hireDate = new Date(originalObject.hireDate);
	}
	public String getName()
	{
		return name;
	}
	public Date getHireDate()
	{
		return new Date(hireDate);
	}
	//precond: newName is not null
	public void setName(String newName)
	{
		if(newName == null)
		{
			System.exit(0);
		}
		name = newName;
	}
	//precond: newDate is not null
	public void setHireDate(Date newDate)
	{
		if(newDate == null)
		{
			System.exit(0);
		}
		hireDate = new Date(newDate);
	}
	public boolean samePay(Employee other)
	{
		if(other == null)
		{
			System.exit(0);
		}
		else
			return (this.getPay() == other.getPay());
	}
	public String toString()
	{
		return (name + " " + hireDate.toString());
	}
	public boolean equals(Employee otherEmployee)
	{
		return(name.equals(otherEmployee.name) && hireDate.equals(otherEmployee.hireDate));
	}
}
