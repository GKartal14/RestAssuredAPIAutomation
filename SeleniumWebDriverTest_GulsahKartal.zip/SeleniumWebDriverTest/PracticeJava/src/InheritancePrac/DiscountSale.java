package InheritancePrac;

public class DiscountSale extends Sale{

	private double discount; // a percent of the price. nonnegative.
	
	public DiscountSale()
	{
		super();
		discount = 0;
	}
	public DiscountSale(String theName, double thePrice, double theDiscount)
	{
		super(theName, theDiscount);
		discount = theDiscount;
	}
	public DiscountSale(DiscountSale originalObject)
	{
		super(originalObject);
		discount = originalObject.discount;
	}
	public static void announcement()
	{
		System.out.println("This is the Discount class.");
	}
	public double bill()
	{
		double fraction = discount / 100;
		return (1 - 0.2) * getPrice(); //getPrice() is the parent method, it is inherited
	}
	public double getDiscount()
	{
		return discount;
	}
	public void setDiscount(double newDiscount)
	{
		if(discount < 0)
		{
			System.exit(0);
		}
		else
		{
			discount = newDiscount;
		}
	}
	public String toString()
	{
		return (getName() + " Price = $ " + getPrice() + " Discount = " + discount + "%n" + " Total cost: " + bill()); 
	}
	
	
}
