package CollectionsPrac;

import java.util.ArrayList;
import java.util.Scanner;

public class GolfScores {

	public static void fillArrayList(ArrayList<Double> a)
	{
		System.out.println("Enter a list of nonnegative numbers.");
		System.out.println("Mark the end of the list with a negative number.");
		
		Scanner keyboard = new Scanner(System.in);
		
		double next;
		next = keyboard.nextDouble();
		
		while(next >= 0)
		{
			a.add(next);
			next = keyboard.nextDouble();
		}
	}
	
	public static double computeAverage(ArrayList<Double> a)
	{
		double total = 0;
		for(double element : a)
			total += element;
		
		int numberOfScores = a.size();
		if(numberOfScores > 0)
		{
			return total / numberOfScores;
		}
		else
		{
			System.out.println("ERROR: Trying to avererage 0 numbers");
			return 0;
		}
	}
	
	//give a screen output showing how much each of the elements in a differ from their average
	
	public static void showDifference(ArrayList<Double> a)
	{
		double average = computeAverage(a);
		
		System.out.println("The scores are: ");
		
		for(Double element : a)
		{
			System.out.println(element + " differs from average by " + (element - average) );
		}
	}
	
	public static void main(String[] args)
	{
		ArrayList<Double> score = new ArrayList<Double>();
		fillArrayList(score);
		showDifference(score);
		
	}
}
