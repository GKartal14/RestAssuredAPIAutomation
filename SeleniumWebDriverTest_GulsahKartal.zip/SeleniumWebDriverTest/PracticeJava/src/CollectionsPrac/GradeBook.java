package CollectionsPrac;

import java.util.Scanner;

public class GradeBook {
	
	private int numberOfStudents; //same as studentAverage.length
	private int numberOfQuizzes; //same as quizAverage.length
	
	private int[][] grade; // numberOfStudents = rows, numberOfQuizzes = columns
	private double[] studentAverage;
	private double[] quizAverage;
	
	public GradeBook(int[][] a)
	{
		if(a.length == 0 || a[0].length == 0)
		{
			System.out.println("empty grade records: abort");
			System.exit(0);
		}
		numberOfStudents = a.length;
		numberOfQuizzes = a[0].length;
		fillGrade(a);
		fillStudentAverage();
		fillQuizAverage();
		
	}
	public GradeBook(GradeBook book)
	{
		numberOfStudents = book.numberOfStudents;
		numberOfQuizzes = book.numberOfQuizzes;
		fillGrade(book.grade);
		fillStudentAverage();
		fillQuizAverage();
	}
	public GradeBook()
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter the number of students: ");
		numberOfStudents = keyboard.nextInt();
		
		System.out.println("Enter the number of quizzes: ");
		numberOfQuizzes = keyboard.nextInt();
		
		grade = new int[numberOfStudents][numberOfQuizzes];
		
		for(int i = 1; i <= numberOfStudents; i++){
			for(int j = 1; j <= numberOfQuizzes; j++)
			{
				System.out.println("Enter score for the student " + i);
				System.out.println("on quiz number: " + j);
				grade[i-1][j-1] = keyboard.nextInt();
			}
		}
		fillStudentAverage();
		fillQuizAverage();
	}
	private void fillGrade(int[][] a)
	{
		grade = new int[numberOfStudents][numberOfQuizzes];
		
		for(int i = 0; i < numberOfStudents; i++)
		{
			for(int j = 0; j < numberOfQuizzes; j++)
			{
				grade[i][j] = a[i][j];
			}
		}
	}
	private void fillStudentAverage()
	{
		studentAverage = new double[numberOfStudents];
		for(int i = 0; i <= numberOfStudents; i++)
		{
			double sum = 0;
			for(int j = 0; j <= numberOfQuizzes; j++)
			{
				sum += grade[i-1][j-1];
			}
			studentAverage[i-1] = sum / numberOfQuizzes;
		}
		
	}
	private void fillQuizAverage()
	{
		quizAverage = new double[numberOfQuizzes];
		for(int i = 0; i < numberOfQuizzes; i++)
		{
			double sum2 = 0;
			for(int j = 0; j < numberOfStudents; j++)
			{
				sum2 += grade[i-1][j-1];
			}
			quizAverage[i-1] = sum2 / numberOfStudents;
		}
	}
	public void display()
	{
		for(int i = 0; i <= numberOfStudents; i++)
		{
			//display for one student
			System.out.print("Student " + i + " Quizzes: ");
			for(int j = 0; j <= numberOfQuizzes; j++)
			{
				System.out.print(grade[i][j] + " ");
				System.out.println("Ave = " + studentAverage[i-1]);
			}
		}
		System.out.println("Quiz averages: " );
		for(int j = 0; j < numberOfQuizzes; j++)
		{
			System.out.print("Quiz " + j + "Ave: " + quizAverage[j-1] + " ");
		}
		System.out.println();
	}
	public static void main(String[] args)
	{
		GradeBook book = new GradeBook();
		book.display();
	}

}
