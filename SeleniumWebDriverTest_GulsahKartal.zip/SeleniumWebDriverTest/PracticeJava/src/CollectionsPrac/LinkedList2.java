package CollectionsPrac;

public class LinkedList2 {// inner class
	
	private class Node
	{
		private String item;
		private Node link;
		
		public Node()
		{
			item = null;
			link = null;
		}
		public Node(String newItem, Node linkValue)
		{
			item = newItem;
			link = linkValue;
		}
	}//End of Node inner class
	
	private Node head;
	
	public LinkedList2()
	{
		head = null;
	}
	public void addToStart(String itemName)
	{
		head = new Node(itemName, head); //ilk node i�in linkValue head olur
	}
	public boolean deleteHeadNode()
	{
		if(head != null)
		{
			head = head.link;
			return true;
		}
		else
		{
			return false;
		}
	}
	public int size()
	{
		int count = 0;
		Node position = head;
		while(position != null)
		{
			count++;
			position = position.link;
		}
		return count;
	}
	private Node find(String target)
	{
		Node position = head;
		String itemAtPosition;
		while(position != null)
		{
			itemAtPosition = position.item;
			if(itemAtPosition.equals(target))
				return position;
			position = position.link;
		}
		return null;
	}
	private boolean contains(String item)
	{
		return (find(item) != null);
	}
	public void outputList()
	{
		Node position = head;
		while(position != null)
		{
			System.out.println(position.item);
			position = position.link;
		}
	}
	public boolean isEmpty()
	{
		return (head = null);
	}
	public void clear()
	{
		head = null;
	}

}
