package RestAssuredTest;

import org.testng.annotations.Test;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONObject;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APITestCase1 {

	@Test
	void createNewUser()
	{
		//Endpoint
		String apiCall = "https://reqres.in/api/users/";
		
		//Prepare JSON payload
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("id","7");
		jsonObj.put("email","gulsah.kartal@regres.in");
		jsonObj.put("first_name","Gulsah");
		jsonObj.put("last_name","Kartal");
		jsonObj.put("avatar","https://reqres.in/img/faces/7-image.jpg");
		String payload = jsonObj.toJSONString();

		//Execute post request
		RequestSpecification requestSpecification = RestAssured.given().contentType("application/json").body(payload);
		Response response = requestSpecification.post(apiCall);
		
		//Obtain status code
		int statusCodeForPostRequest = response.getStatusCode();
		System.out.println("Status code for post request is: " + statusCodeForPostRequest);
		String statusLineForPostRequest = response.statusLine();
		System.out.println("Status line for post request is: " + statusLineForPostRequest);
		String jsonFormattedBody = response.asPrettyString();
		System.out.println("JSON response of the post request is: " + jsonFormattedBody);

		//Write on a JSON file and 
		try (FileWriter f = new FileWriter("responsePost.json"))
		{
			f.write(jsonFormattedBody);
			f.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
}
