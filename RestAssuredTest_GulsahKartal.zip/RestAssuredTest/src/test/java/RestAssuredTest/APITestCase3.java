package RestAssuredTest;

import java.io.FileWriter;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class APITestCase3 {

	@Test
	void deleteUser()
	{
		//Endpoint
		String apiCall = "https://reqres.in/api/users";
		
		//Get the entire list of users first
		RequestSpecification requestSpecificationForGet = RestAssured.given().contentType("application/json");
		Response responseGet = requestSpecificationForGet.get(apiCall);
		
		//Obtain status code for the GET request
		int statusCodeForGetRequest = responseGet.getStatusCode();
		System.out.println("Status code for get request is: " + statusCodeForGetRequest);
		
		/*Below is the info of the chosen user
		    "id": 3,
		    "email": "emma.wong@reqres.in",
		    "first_name": "Emma",
		    "last_name": "Wong",
		    "avatar": "https://reqres.in/img/faces/3-image.jpg"
		*/
		//Prepare the JSON payload, choose the third item for deletion
		JSONObject jsonObj = new JSONObject();
		jsonObj.getOrDefault("id", "3");
		String payload = jsonObj.toJSONString();
		
		//Execute delete request
		RequestSpecification requestSpecification = RestAssured.given().contentType("application/json").body(payload);
		Response response = requestSpecification.delete(apiCall);
		
		//Obtain status code, for successful deletion, we should get 204 status code.
		int statusCodeForDeleteRequest = response.getStatusCode();
		System.out.println("Status code for delete request is: " + statusCodeForDeleteRequest);
		String statusLineForDeleteRequest = response.statusLine();
		System.out.println("Status line for delete request is: " + statusLineForDeleteRequest);
						
	}
}
